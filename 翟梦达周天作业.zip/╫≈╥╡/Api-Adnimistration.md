

# 1.1查询商品列表
URL: /product/search?productName={productName}&model={model}&price={price}&quantity={quantity}&status={status}&pageNum={pageNum}
Method：GET

RequestBody:  
```json
{ 
    "pageNum":1,
    "pageSize":1,
    "total":10,
    "list":[
        {
        "product_id":666,
        "product_name": "苹果果",
        "price": 6666,
        "discount": 0.5,
        "quantity": 1,
        "status": 0,
        "main_pic_url": "666.png",
        "reword_points": 21
        },
        {
        "product_id":666,
        "product_name": "苹果果",
        "price": 6666,
        "discount": 0.5,
        "quantity": 1,
        "status": 0,
        "main_pic_url": "666.png",
        "reword_points": 21
        }
    ]
    
    
    
} 
```


Request Field  

| 字段    |   类型 |   描述   | 
|---|---|---|
| pageNum | int  | 当前页数  |
| product_name | varchar(100)  | 商品名称  |
| product_code | varchar(50)  |  商品代码  |
| price  | double  | 价格  |
| quantity  | int  |  库存数量  |
| status  | tinyint  |  状态（0下架、1上架、2待审核）  |

Response Field  

| 字段  | 类型  |  说明 |
|---|---|---|---|
| pageNum  | int  | 当前页数  |
| pageSize  | int  | 每页条数  |
| total  | int  | 总条数  |
| list  | array  | 数据列表  |
| product_id  | int  | Id  |
| product_code | varchar(50)  | 商品代码  |
| product_name | varchar(100)  | 商品名称  |
| price  | double  | 非空 | 价格  |
| discount  | double  | 打折（0.01-0.99）  |
| quantity  | int  | 库存数量  |
| status  | tinyint  | 状态（0下架、1上架、2待审核）  |
| main_pic_url | varchar(100)  | 主图  |
| reword_points  | int  | 积分  |


## 1.2 商品添加

URL: /product/create  
Method：POST  

RequestBody:  
```json
{
    "product_name": "苹果果",
    "price": 6666,
    "discount": 0.5,
    "quantity": 1,
    "status": 0,
    "main_pic_url": "666.png",
    "reword_points": 21
}
```

ResponseBody:  
```
123456

```

Request Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
| product_code | varchar(50)  | 商品代码  |
| product_name | varchar(100)  | 商品名称  |
| price  | double  | 非空 | 价格  |
| discount  | double  | 打折（0.01-0.99）  |
| quantity  | int  | 库存数量  |
| status  | tinyint  | 状态（0下架、1上架、2待审核）  |
| main_pic_url | varchar(100)  | 主图  |
| reword_points  | int  | 积分  |

Response Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
|    | Integer   | 商品Id    |




## 1.3 商品编辑

URL: /product/update  
Method：POST  

RequestBody:  
```json
    {
        "product_id":666,
        "product_name": "苹果果",
        "price": 6666,
        "discount": 0.5,
        "quantity": 1,
        "status": 0,
        "main_pic_url": "666.png",
        "reword_points": 21
    }
```

Request Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
| product_id  | int  | Id  |
| product_code | varchar(50)  | 商品代码  |
| product_name | varchar(100)  | 商品名称  |
| price  | double  | 非空 | 价格  |
| discount  | double  | 打折（0.01-0.99）  |
| quantity  | int  | 库存数量  |
| status  | tinyint  | 状态（0下架、1上架、2待审核）  |
| main_pic_url | varchar(100)  | 主图  |
| reword_points  | int  | 积分  |

# 1.4查询客户列表
URL: /customer/search?customerName={customerName}&email={email}&customerGroup={customerGroup}&status={status}&pageNum={pageNum}  
Method：GET

ResponseBody:  
```json
{ 
    "pageNum":1,
    "pageSize":2,
    "total":10,
    "list":[
        {
        "customer_id":666,
        "customer_name": "苹果果",
        "email": "www.333@qq.com",
        "customer_group": 6,
        "status": 0,
        "ip": "192.68.23.11",
        "date_added": "2020-02-23"
        },
         {
        "customer_id":666,
        "customer_name": "苹果果",
        "email": "www.333@qq.com",
        "customer_group": 6,
        "status": 0,
        "ip": "192.68.23.11",
        "date_added": "2020-02-23"
        }
    ]
    
    
    
} 
```


Request Field  

| 字段    |   类型 |   描述   | 
|---|---|---|
| pageNum | int  | 当前页数  |
| customerName | varchar(20)  | 客户名称  |
| email | varchar(50)  |  客户邮箱  |
| customerGroup  | int  | 客户所在组  |
| status  | tinyint  |  状态（0在线、1离线）  |

Response Field  

| 字段  | 类型  |  说明 |
|---|---|---|---|
| pageNum  | int  | 当前页数  |
| pageSize  | int  | 每页条数  |
| total  | int  | 总条数  |
| list  | array  | 数据列表  |
| customer_id  | int  | 客户Id  |
| customer_name | varchar(20)  | 客户名称  |
| email | varchar(100)  | 客户邮箱  |
| customer_group  | int  | 客户所在组  |
| status  | tinyint  |  状态（0在线、1离线）  |
| ip  | varchar(25)  |  客户IP地址  |
| date_added  | dateTime  |  客户创建时间 |



# 1.4查询订单列表
URL: /order/search?orderId={orderId}&customer={customer}&orderStatus={orderStatus}&totalPrice={totalPrice}&dateAdded={dateAdded}&pageNum={pageNum}  
Method：GET

ResponseBody:  
```json
{
    "pageNum":1,
    "pageSize":2,
    "total":10,
    "list":[
        {
        "order_id":666,
        "customer_name": "zd",
        "total_price": 6666.66,
        "status": 0,
        "date_added": "2020-02-23",
        "date_modified": "2020-02-26",
        },
        {
        "order_id":666,
        "customer_name": "zd",
        "customer_group": 6,
        "total_price": 6666.66,
        "status": 0,
        "date_added": "2020-02-23",
        "date_modified": "2020-02-26",
        }
    ]
    
    
    
} 
```

Request Field  

| 字段    |   类型 |   描述   | 
|---|---|---|
| pageNum | int  | 当前页数  |
| orderId | int  | 订单id  |
| customer | varchar(50)  |  客户名称  |
| totalPrice  | double  | 订单总金额  |
| orderStatus  | tinyint  |  订单状态  |
| dateAdded  | dateTime  |  订单创建时间 |

Response Field  

| 字段  | 类型  |  说明 |
|---|---|---|---|
| pageNum  | int  | 当前页数  |
| pageSize  | int  | 每页条数  |
| total  | int  | 总条数  |
| list  | array  | 数据列表  |
| order_id  | int  | 订单Id  |
| customer_name | varchar(20)  | 客户名称  |
| total_price  | double  | 订单总金额  |
| status  | tinyint  |  订单状态  |
| date_added  | dateTime  |  订单创建时间 |
| date_modified  | dateTime  |  订单修改时间  |


## 1.5 退货申请列表页
URL: /return/search?returnId={returnId}&orderId={orderId}&customer={customer}&product={product}&model={model}&returnStatus={returnStatus}&pageNum={pageNum}  
Method：GET

ResponseBody:  
```json
{
    "pageNum":1,
    "pageSize":2,
    "total":10,
    "list":[
        {
        "return_id":666,
        "order_id":666,
        "customer_name": "zd",
        "product": "iphone",
        "status": 0,
        "date_added": "2020-02-23",
        "date_modified": "2020-02-26",
        },
         {
        "return_id":666,
        "order_id":666,
        "customer_name": "zd",
        "product": "iphone",
        "status": 0,
        "date_added": "2020-02-23",
        "date_modified": "2020-02-26",
        }
    ]
    
    
    
} 
```

Request Field  

| 字段    |   类型 |   描述   | 
|---|---|---|
| pageNum | int  | 当前页数  |returnId
| returnId | int  | 退货id  |
| orderId | int  | 订单id  |
| customer | varchar(20)  |  客户名称  |
| product  | varchar(20)  | 商品名称  |
| model  | varchar(50)  |  商品型号  |
| returnStatus  | tinyint  |  退货状态 |

Response Field  

| 字段  | 类型  |  说明 |
|---|---|---|---|
| pageNum  | int  | 当前页数  |
| pageSize  | int  | 每页条数  |
| total  | int  | 总条数  |
| list  | array  | 数据列表  |
| return_id | int  | 退货id  |
| order_id  | int  | 订单Id  |
| customer_name | varchar(20)  | 客户名称  |
| product  | varchar(20)  | 商品名称  |
| model  | varchar(20)  | 商品型号  |
| status  | tinyint  |  退货状态  |
| date_added  | dateTime  |  退货创建时间 |
| date_modified  | dateTime  |  退货修改时间  |

## 1.6 退货编辑回显
URL: /return/getById?returnId={returnId}
Method：GET

RequestBody:  
```json
{
    "return_id":666
}
```

ResponseBody:  
```json

    {
    "return_id":666,
    "order_id":666,
    "customer_name": "zd",
    "product": "iphone",
    "status": 0,
    "date_added": "2020-02-23",
    "date_modified": "2020-02-26",
    }
 
```

Request Field  

| 字段    |   类型 |   描述   | 
|---|---|---|
| returnId | int  | 退货id  |


Response Field  
| order_id  | int  | 订单Id  |
| order_date  | dateTime  | 订单退货日期  |
| customer_name | varchar(20)  | 客户名称  |
| first_name | varchar(20)  | 姓氏  |
| last_name | varchar(20)  | 名字  |
| email | varchar(50)  | 客户邮箱  |

## 1.7 退货历史页
URL: /returnhistory/search?orderId={orderId}&pageNum={pageNum}  
Method：GET

ResponseBody:  
```json
{
    "pageNum":1,
    "pageSize":2,
    "total":10,
    "list":[
        {
        "status": 0,
        "comment":"退货进度",
        "date_added": "2020-02-23",
        "customer_nodified": 1,
        },
        {
        "status": 0,
        "comment":"退货进度",
        "date_added": "2020-02-23",
        "customer_nodified": 1,
        }
    ]
    
    
    
} 
```

Request Field  

| 字段    |   类型 |   描述   | 
|---|---|---|
| pageNum | int  | 当前页数  |returnId
| orderId | int  | 订单id  |


Response Field  

| 字段  | 类型  |  说明 |
|---|---|---|---|
| pageNum  | int  | 当前页数  |
| pageSize  | int  | 每页条数  |
| total  | int  | 总条数  |
| list  | array  | 数据列表  |
| status  | tinyint  |  退货状态  |
| date_added  | dateTime  |  退货创建时间 |
| comment  | varchar(20)  |  退货进度 |
| customer_nodified  | tinyint  |  是否通知客户  |


## 1.8 查询管理员列表

URL: /administrator/index?pageNum={pageNum}  
Method：GET  

ResponseBody:  
```json
{
    "total": 13,
    "pageNum": 2,
    "pageSize": 10,
    "list": [
        {
            "administratorId": 1234,
            "username": "user01",
            "status": 1,
            "createTimestamp": 1580784600372
        },
        {
            "administratorId": 1235,
            "username": "user02",
            "status": 0,
            "createTimestamp": 1580784711504
        }
    ]
}
```

Request Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
| pageNum   | Integer   | 当前页码    |

Response Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
| total   | Integer   | 总数    |
| pageNum   | Integer   | 当前页码    |
| pageSize   | Integer   | 一页数量    |
| list   | Array   | 列表数据    |
| administratorId   | Integer   | 管理员Id    |
| username   | String   | 用户名    |
| status   | Byte   | 状态    |
| createTime   | Long   | 创建时间    |

## 1.9 创建管理员

URL: /administrator/create  
Method：POST  

RequestBody:  
```json
{
    "username": "user01",
    "realName": "张三",
    "mobile": "13234567890",
    "email": "aa@qq.com",
    "password": "123456",
    "status": 1,
    "avatarUrl": "xxx.jpg"
}
```

ResponseBody:  
```
123456

```

Request Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
| username   | String   | 用户名    |
| realName   | String   | 真实姓名    |
| mobile   | String   | 手机    |
| email   | String   | 邮箱    |
| password   | String   | 密码    |
| status   | Byte   | 状态    |
| avatarUrl   | String   | 头像Url    |

Response Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
|    | Integer   | 管理员Id    |

## 2.0 更新管理员

URL: /administrator/update  
Method：POST  

RequestBody:  
```json
{
    "administratorId": 123456,
    "username": "user01",
    "realName": "张三",
    "mobile": "13234567890",
    "email": "aa@qq.com",
    "password": "123456",
    "status": 1,
    "avatarUrl": "xxx.jpg"
}
```

Request Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
| administratorId   | Integer   | 管理员Id    |
| username   | String   | 用户名    |
| realName   | String   | 真实姓名    |
| mobile   | String   | 手机    |
| email   | String   | 邮箱    |
| password   | String   | 密码    |
| status   | Byte   | 状态    |
| avatarUrl   | String   | 头像Url    |

## 2.1 管理员登陆

URL: /administration/login?username={username}&password={password}  
Method：GET  

ResponseBody:  
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c
```

Request Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
| username   | String   | 用户名    |
| password   | String   | 密码    |

Response Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
|    | String   | jwt token    |


## 2.2 管理员忘记密码页
URL: /administration/forgot?email={email}  
Method：post

RequestBody:  
```json
{
    "email":"www.666@qq.com"
}
```

RequestBody:  
```json
{
    
    "username": "admin",
    "password": "123456",

}
```

Request Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
| email   | String   | 邮箱    |

Response Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
|  username  | String   | 用户名    |
|  password  | String   | 密码    |


## 2.3 管理员个人信息页
URL: /administaration/getByName={getByName}
Method：GET

RequestBody:  
```json
{
    "username":"admin"
}
```

ResponseBody:  
```json

    {
    "username":"admin",
    "first_name":"john",
    "last_name": "Doe",
    "email": "www.99@qq.com",
    "img": "administarationPicUrl",
    }
 
```

Request Field  

| 字段    |   类型 |   描述   | 
|---|---|---|
| username | varchar(20)  | 管理员名称  |


Response Field  
| username  | int  | 订单Id  |
| order_date  | varchar(20)  | 管理员名称  |
| first_name | varchar(20)  | 姓氏  |
| last_name | varchar(20)  | 名字  |
| email | varchar(50)  | 客户邮箱  |
| img | varchar(20)  | 管理员头像  |

## 2.4 退货详情
URL: /return/getById?returnId={returnId}
Method：GET

RequestBody:  
```json
{
    "returnId":1
}
```

ResponseBody:  
```json

    {
    "return_id":1,
    "product_name":"iphone",
    "model": "iphone 11",
    "quantity": 1,
    "reason": "有裂纹",
    "opened": 1,
    "date_added":"2020-02-30",
    "status":2
    }
 
```

Request Field  

| 字段    |   类型 |   描述   | 
|---|---|---|
| returnId | int  | 退货id  |


Response Field 
| 字段    |   类型 |   描述   | 
|---|---|---| 
| return_id | int  | 退货id  |
| product_name  | varchar(20)  | 商品名称  |
| model | varchar(20)  | 商品型号  |
| quantity | int  | 商品数量  |
| reason | varchar(50)  | 退货理由  |
| opened | tinyint  | 是否开封  |
| date_added | dateTime  | 买货时间  |
| status | tinyint  | 退货状态  |


## 2.5 图片上传

URL: /image/upload  
Method：POST  
Request Content-Type: multipart/formdata  
RequestParam: image  

ResponseBody:  
```json
xxx.jpg
```

Request Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
| image   | String   | 上传图片    |

Response Field  

| 字段     |     类型 |   描述   | 
| :--------------: | :--------:| :------: |
|    | String   | 上传图片后Url    |
